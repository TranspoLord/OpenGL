#include <iostream>
#include <glm/glm.hpp>
#include <GL/glew.h>
#include <vector>

using namespace std;

class CylinderObject {
public:
	vector<GLfloat> buildCylinder(float height, float radius, int sectors) {
		std::vector<float> vertices;
		std::vector<float> normals;
		std::vector<float> texCoords;

		// Make caps
		const float PI = acos(-1);
		float sectorStep = 2 * PI / sectors;
		float sectorAngle;  // radian

		cout << "Building cylinder" << endl;
		for (int j = 0; j < 2; ++j) {
			float h = -height / 2.0f + j * height;           // z value; -h/2 to h/2
			// Normals
			float nx, ny, nz;
			nx = 0;
			ny = 0;
			nz = (j * 2) - 1;

			for (int i = 0; i <= sectors; ++i)
			{
				sectorAngle = i * sectorStep;

				vertices.push_back(cos(sectorAngle) * radius);
				vertices.push_back(sin(sectorAngle) * radius);
				vertices.push_back(h);

				vertices.push_back(cos(sectorAngle + sectorStep) * radius);
				vertices.push_back(sin(sectorAngle + sectorStep) * radius);
				vertices.push_back(h);

				vertices.push_back(0);
				vertices.push_back(0);
				vertices.push_back(h);

				normals.push_back(nx);
				normals.push_back(ny);
				normals.push_back(nz);
				normals.push_back(nx);
				normals.push_back(ny);
				normals.push_back(nz);
				normals.push_back(nx);
				normals.push_back(ny);
				normals.push_back(nz);

				texCoords.push_back(0);
				texCoords.push_back(0);

				texCoords.push_back(0);
				texCoords.push_back(0);

				texCoords.push_back(0);
				texCoords.push_back(0);
			}
		}

		// Sides
		for (int i = 0; i <= sectors; ++i)
		{
			sectorAngle = i * sectorStep;
			// Calc normals
			float nx, ny, nz;
			nx = cos(sectorAngle);
			ny = sin(sectorAngle);
			nz = 0;

			for (int j = 0; j < 2; ++j) {
				float h = -height / 2.0f + j * height;                // z value; -h/2 to h/2
				float h2 = -height / 2.0f + (1 - j) * height;           // z value; -h/2 to h/2

				vertices.push_back(cos(sectorAngle) * radius);
				vertices.push_back(sin(sectorAngle) * radius);
				vertices.push_back(h);

				vertices.push_back(cos(sectorAngle + (sectorStep)) * radius);
				vertices.push_back(sin(sectorAngle + (sectorStep)) * radius);
				vertices.push_back(h);

				vertices.push_back(cos(sectorAngle + (sectorStep * j)) * radius);
				vertices.push_back(sin(sectorAngle + (sectorStep * j)) * radius);
				vertices.push_back(h2);

				normals.push_back(nx);
				normals.push_back(ny);
				normals.push_back(nz);
				normals.push_back(nx);
				normals.push_back(ny);
				normals.push_back(nz);
				normals.push_back(nx);
				normals.push_back(ny);
				normals.push_back(nz);

				texCoords.push_back(0.0f);
				texCoords.push_back(0.0f);

				texCoords.push_back(1.0f);
				texCoords.push_back(0.0f);

				texCoords.push_back(1.0f);
				texCoords.push_back(1.0f);
			}
		}
		// Construct the GLfloat array
		std::vector<GLfloat> model;
		for (int verts = 0, norms = 0, text = 0; verts < vertices.size(); verts += 3, norms += 3, text = +2) {
			// verts
			model.push_back(vertices.at(verts));
			model.push_back(vertices.at(verts + 1));
			model.push_back(vertices.at(verts + 2));
			// normal
			model.push_back(normals.at(norms));
			model.push_back(normals.at(norms + 1));
			model.push_back(normals.at(norms + 2));
			// text
			model.push_back(texCoords.at(text));
			model.push_back(texCoords.at(text + 1));
		}
		cout << "Cylinder build complete" << endl;
		return model;
	}

	GLuint vao;
	GLuint vbo;
	GLuint nIndices;
	GLuint nVertices;
	glm::mat4 scale;
	glm::mat4 rotation;
	glm::mat4 translation;
	glm::mat4 model;
private:
	vector<float> verts;
	vector<float> indices;
};




